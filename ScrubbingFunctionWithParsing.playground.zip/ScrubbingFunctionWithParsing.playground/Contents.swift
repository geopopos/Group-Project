// ScrubbingFunctionWithParsing.playground
import UIKit
import Foundation

extension String { // Extends String with a useful function
    func indexes(of string: String, options: CompareOptions = .literal) -> [Index] {
        var result: [Index] = []
        var start = startIndex
        while let range = range(of: string, options: options, range: start..<endIndex) {
            result.append(range.lowerBound)
            start = range.upperBound
        }
        return result
    }
}

let year = "17" // Choose year and semester
let semester = "SP"
//"AMS ANT ART BIO BLS BUS CHE CHN CSI DAN ECN EDU ELL ENG ENV FRS GEN GRS GRW HIS HMN HPS ILC INM MAT MUS PED PHL PHY POL PSY SOC THE"
let deptString = "AMS ANT ART BIO BLS BUS CHE CHN CSI DAN ECN EDU ELL ENG ENV FRS GEN GRS GRW HIS HMN HPS ILC INM MAT MUS PED PHL PHY POL PSY SOC THE" // List any departments here, separate them with spaces
let myURLString = "https://admin.washcoll.edu/schedules/"+year+semester+"schedules.html" // Create url to grab courses from
let myURL = NSURL(string: myURLString)
var myHTMLString = try String(contentsOf: myURL! as URL) // Create a string with the contents of the URL (page source)

var deptStringArray = deptString.components(separatedBy: " ") // Add department names to array
var indexArray = Array<[String.Index]>() // Create array to store the indexes of where each department name appears
let recommended = myHTMLString.indexes(of: "recommended") // Save the index of the recommended string, where the schedule ends
for x in 0...deptStringArray.count-1 { // Add a space to each department name then append the indexes where the names appear
    deptStringArray[x] = deptStringArray[x] + " "
    indexArray.append(myHTMLString.indexes(of: deptStringArray[x]))
}

// The following function takes an index and size(int) and returns string to print -> returns all useful info about class
private func getClassInfo(at Index: String.Index, size: Int) -> String {
    var string = String() // The string where we want to store our characters following the given index
    
    for var x in 0...size { // For however long we wish to make the string, iterate for each string character
        if myHTMLString.index(Index, offsetBy: x) < recommended[0] { // if current index is before the 'recommended'
            let charAtIndex = myHTMLString[myHTMLString.index(Index, offsetBy: x)] // find character at that index
            
            if charAtIndex == Character("A") { // Avoid adding HTML code like '</A>'
                if myHTMLString[myHTMLString.index(Index, offsetBy: x-1)] != Character("/") {
                    string = string + String(charAtIndex)
                }
            }
            else if charAtIndex == Character("0") && (myHTMLString[myHTMLString.index(Index, offsetBy: x-1)] == Character(" ") || myHTMLString[myHTMLString.index(Index, offsetBy: x-1)] == Character("-")) { // Reformat the way time is displayed
                string = string + " "
            }
            else if charAtIndex != Character("<") && charAtIndex != Character("/") && charAtIndex != Character(">") && charAtIndex != Character("-") { // Avoid adding special characters
                string = string + String(charAtIndex)
            }
            if string.characters.count == 11 || string.characters.count == 43 { // Add a space here or here if one doesn't exist
                if myHTMLString[myHTMLString.index(Index, offsetBy: x+1)] != Character(" "){
                    string = string + " "
                }
            }
            if string.characters.count == 68 {
                if myHTMLString[myHTMLString.index(Index, offsetBy: x-1)] == Character("M") {
                    string = string + " - "
                }
            }
            if string.characters.count == 2 { // Get rid of strings that start with spaces or 'sp'
                if string == "  " || string == "sp"{
                    string = ""
                    x = size
                }
            }
            if string.characters.count == 5 {  // The string should have the fifth character being a 0,1,2,3,4 if it's a string we desire
                if charAtIndex != Character("0") && charAtIndex != Character("1") && charAtIndex != Character("2") && charAtIndex != Character("3") && charAtIndex != Character("4") {
                    string = ""
                    x = size
                }
            }
        }
    }
    
    if string.indexes(of: "                                 ") != [] || string.indexes(of: "TBA") != []{ // Make sure strings dont have abundant blank space or contain TBA
        string = ""
    }
    
    if string.characters.count > 5 { // Eliminate all small nonsensical strings
        return string
    }
    else{return ""} // If criteria doesn't fit return blank string
}

// Now that we have all the indexes saved and a function that takes an index and returns the string that follows, we can store these strings in an array and print when desired.
var splitStringArray = Array<String>() // Create string array

for x in 0...indexArray.count-1 { // For however many departments we are searching
    if indexArray[x] != [] { // If the department has a class
        let currentIndex : [String.Index] = indexArray[x]
        for x in 0...currentIndex.count-1{ // For as many indexes in current department
            let string = getClassInfo(at: currentIndex[x], size: 93) // Let the string be the first 'size' characters after the given index
            if string != "" { // Only if string isnt empty
                splitStringArray.append(string) // Append string to our string array
            }
        }
        splitStringArray.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~") // Divide each departments classes
    }
} // get a string for each class and append the string to a string array

var ArrayMWF = Array<String>()
var ArrayMWFa = Array<String>()
var ArrayMWFb = Array<String>()
var ArrayTTH = Array<String>()
var ArrayTTHa = Array<String>()
var ArrayTTHb = Array<String>()
var ArrayMW = Array<String>()
var ArrayMWa = Array<String>()
var ArrayMWb = Array<String>()
var ArrayMF = Array<String>()
var ArrayMFa = Array<String>()
var ArrayMFb = Array<String>()
var ArrayWF = Array<String>()
var ArrayWFa = Array<String>()
var ArrayWFb = Array<String>()
var ArrayTH = Array<String>()
var ArrayTHa = Array<String>()
var ArrayTHb = Array<String>()
var ArrayM = Array<String>()
var ArrayMa = Array<String>()
var ArrayMb = Array<String>()
var ArrayW = Array<String>()
var ArrayWa = Array<String>()
var ArrayWb = Array<String>()
var ArrayF = Array<String>()
var ArrayFa = Array<String>()
var ArrayFb = Array<String>()
var ArrayT = Array<String>()
var ArrayTa = Array<String>()
var ArrayTb = Array<String>()


for x in 0...splitStringArray.count-1 {
    if splitStringArray[x].contains(" MWF ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayMa.append(splitStringArray[x])
            ArrayWa.append(splitStringArray[x])
            ArrayFa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayMb.append(splitStringArray[x])
            ArrayWb.append(splitStringArray[x])
            ArrayFb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" TTH ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayTa.append(splitStringArray[x])
            ArrayTHa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayTb.append(splitStringArray[x])
            ArrayTHb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" MW ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayMa.append(splitStringArray[x])
            ArrayWa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayMb.append(splitStringArray[x])
            ArrayWb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" MF ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayMa.append(splitStringArray[x])
            ArrayFa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayMb.append(splitStringArray[x])
            ArrayFb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" WF ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayWa.append(splitStringArray[x])
            ArrayFa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayWb.append(splitStringArray[x])
            ArrayFb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" TH ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayTHa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayTHb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" M ") {
        if splitStringArray[x].contains(", M ") {}
        else{
            let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
            if char == Character("A") {
                ArrayMa.append(splitStringArray[x])
            }
            else if char == Character("P") {
                ArrayMb.append(splitStringArray[x])
            }
        }
    }
    else if splitStringArray[x].contains(" W ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayWa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayWb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" F ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayFa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayFb.append(splitStringArray[x])
        }
    }
    else if splitStringArray[x].contains(" T ") {
        let char = splitStringArray[x][splitStringArray[x].index(splitStringArray[x].startIndex, offsetBy: 66)]
        if char == Character("A") {
            ArrayTa.append(splitStringArray[x])
        }
        else if char == Character("P") {
            ArrayTb.append(splitStringArray[x])
        }
    }
    else {}
} // Appends strings to correct Day/Time Array

func printAMValues(with array: Array<String>) {
    if array.count != 0 {
        var PrintArrayMWF = Array<String>()
        var doubleArray = Array<Double>()
        var stringDoubleArray = Array<Double>()
    
//        for x in 0...array.count-1 {
//            PrintArrayMWF.append("")
//        }
        
        for x in 0...array.count-1 {
            
            var appendChar1 = true
            let charAtIndex1 = array[x][array[x].index(array[x].startIndex, offsetBy: 61)]
            let charAtIndex2 = array[x][array[x].index(array[x].startIndex, offsetBy: 62)]
            let charAtIndex3 = array[x][array[x].index(array[x].startIndex, offsetBy: 64)]
            var string = String()
            
            if String(charAtIndex1) == " " {appendChar1 = false}
            if appendChar1 == true{string = String(charAtIndex1) + String(charAtIndex2) + "." + String(charAtIndex3)}
            else {string = String(charAtIndex2) + "." + String(charAtIndex3)}
            let double = Double(string)!
            doubleArray.append(double)

        }
        
        doubleArray.sort()
    
        for x in 0...array.count-1 {
            var appendChar1 = true
            let charAtIndex1 = array[x][array[x].index(array[x].startIndex, offsetBy: 61)]
            let charAtIndex2 = array[x][array[x].index(array[x].startIndex, offsetBy: 62)]
            let charAtIndex3 = array[x][array[x].index(array[x].startIndex, offsetBy: 64)]
            var string = String()
            if String(charAtIndex1) == " " {appendChar1 = false}
            if appendChar1 == true{string = String(charAtIndex1) + String(charAtIndex2) + "." + String(charAtIndex3)}
            else {string = String(charAtIndex2) + "." + String(charAtIndex3)}
            stringDoubleArray.append(Double(string)!)
        }
        
        for x in 0...doubleArray.count-1 {
            for var y in 0...stringDoubleArray.count-1 {
                if doubleArray[x] == stringDoubleArray[y] {
                    stringDoubleArray[y] = 0
                    PrintArrayMWF.append(array[y])
                    y = stringDoubleArray.count-1
                }
            }
        }
        for x in 0...PrintArrayMWF.count-1 {
            print(PrintArrayMWF[x])
        }
    }
} // Prints out the AM Values

func printPMValues(with array: Array<String>) {
    if array.count != 0 {
        var PrintArrayMWF = Array<String>()
        var doubleArray = Array<Double>()
        var stringDoubleArray = Array<Double>()
        
        //        for x in 0...array.count-1 {
        //            PrintArrayMWF.append("")
        //        }
        
        for x in 0...array.count-1 {
            
            var appendChar1 = true
            let charAtIndex1 = array[x][array[x].index(array[x].startIndex, offsetBy: 61)]
            let charAtIndex2 = array[x][array[x].index(array[x].startIndex, offsetBy: 62)]
            let charAtIndex3 = array[x][array[x].index(array[x].startIndex, offsetBy: 64)]
            var string = String()
            
            if String(charAtIndex1) == " " {appendChar1 = false}
            if appendChar1 == true{string = String(charAtIndex1) + String(charAtIndex2) + "." + String(charAtIndex3)}
            else {string = String(charAtIndex2) + "." + String(charAtIndex3)}
            let double = Double(string)!
            doubleArray.append(double)
            
        }
        
        doubleArray.sort()
        
        for x in 0...array.count-1 {
            var appendChar1 = true
            let charAtIndex1 = array[x][array[x].index(array[x].startIndex, offsetBy: 61)]
            let charAtIndex2 = array[x][array[x].index(array[x].startIndex, offsetBy: 62)]
            let charAtIndex3 = array[x][array[x].index(array[x].startIndex, offsetBy: 64)]
            var string = String()
            if String(charAtIndex1) == " " {appendChar1 = false}
            if appendChar1 == true{string = String(charAtIndex1) + String(charAtIndex2) + "." + String(charAtIndex3)}
            else {string = String(charAtIndex2) + "." + String(charAtIndex3)}
            stringDoubleArray.append(Double(string)!)
        }
        
        for x in 0...doubleArray.count-1 {
            for var y in 0...stringDoubleArray.count-1 {
                if doubleArray[x] == stringDoubleArray[y] {
                    stringDoubleArray[y] = 0
                    PrintArrayMWF.append(array[y])
                    y = stringDoubleArray.count-1
                }
            }
        }
        
        var bool = false
        var classesMoved = 0
        while bool == false {
            for x in 0...PrintArrayMWF.count-1{
                let charAtIndex1 = PrintArrayMWF[(PrintArrayMWF.count-1)-x][PrintArrayMWF[(PrintArrayMWF.count-1)-x].index(PrintArrayMWF[(PrintArrayMWF.count-1)-x].startIndex, offsetBy: 61)]
                let charAtIndex2 = PrintArrayMWF[(PrintArrayMWF.count-1)-x][PrintArrayMWF[(PrintArrayMWF.count-1)-x].index(PrintArrayMWF[(PrintArrayMWF.count-1)-x].startIndex, offsetBy: 62)]
                if charAtIndex1 == Character("1") && charAtIndex2 == Character("2") {
                    let string = PrintArrayMWF[(PrintArrayMWF.count-1)-x]
                    PrintArrayMWF.insert(string, at: 0)
                    classesMoved += 1
//                    PrintArrayMWF.remove(at: (PrintArrayMWF.count-1)-x)
                }
                else {bool = true}
            }
        }
        
        if classesMoved != 0 {
            for _ in 0...classesMoved-1 {
                PrintArrayMWF.remove(at: (PrintArrayMWF.count-1))
            }
        }
        
        for x in 0...PrintArrayMWF.count-1 {
            print(PrintArrayMWF[x])
        }
    }
} // Prints out the PM Values

func printAll() {
    print("") // Schedule Header
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  Schedule  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("")
    print("Dpt Cls Sec Name                            Bld  Rm   Day           Time        Prof")
    print("")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  Monday  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if ArrayMa != [] {printAMValues(with: ArrayMa)}
    if ArrayMb != [] {printPMValues(with: ArrayMb)}
    print("")
    print("")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  Tuesday  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if ArrayTa != [] {printAMValues(with: ArrayTa)}
    if ArrayTb != [] {printPMValues(with: ArrayTb)}
    print("")
    print("")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  Wednesday  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if ArrayWa != [] {printAMValues(with: ArrayWa)}
    if ArrayWb != [] {printPMValues(with: ArrayWb)}
    print("")
    print("")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  Thursday  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if ArrayTHa != [] {printAMValues(with: ArrayTHa)}
    if ArrayTHb != [] {printPMValues(with: ArrayTHb)}
    print("")
    print("")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  Friday  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    if ArrayFa != [] {printAMValues(with: ArrayFa)}
    if ArrayFb != [] {printPMValues(with: ArrayFb)}
    print("")
} // Prints every class hosted on each day of the week in desc. order starting with Monday

printAll()