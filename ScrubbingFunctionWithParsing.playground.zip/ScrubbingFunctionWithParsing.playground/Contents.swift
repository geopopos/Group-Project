// ScrubbingFunctionWithParsing.playground

import UIKit
import Foundation


extension String { // Extends String with 4 useful functions
    func index(of string: String, options: CompareOptions = .literal) -> Index? {
        return range(of: string, options: options)?.lowerBound
    }
    func endIndex(of string: String, options: CompareOptions = .literal) -> Index? {
        return range(of: string, options: options)?.upperBound
    }
    func indexes(of string: String, options: CompareOptions = .literal) -> [Index] {
        var result: [Index] = []
        var start = startIndex
        while let range = range(of: string, options: options, range: start..<endIndex) {
            result.append(range.lowerBound)
            start = range.upperBound
        }
        return result
    }
    func ranges(of string: String, options: CompareOptions = .literal) -> [Range<Index>] {
        var result: [Range<Index>] = []
        var start = startIndex
        while let range = range(of: string, options: options, range: start..<endIndex) {
            result.append(range)
            start = range.upperBound
        }
        return result
    }
}


//set get these values and set them using the function parameters
let year = "17"
let semester = "SP"
var StringsFixed = 0
//create url to grab courses from
let myURLString = "https://admin.washcoll.edu/schedules/"+year+semester+"schedules.html"
let myURL = NSURL(string: myURLString)

var myHTMLString = String()

//get html of specified page
do {
    myHTMLString = try String(contentsOf: myURL! as URL)
    
} catch let error as NSError {
    print("Error: \(error)")
}


let index1 = myHTMLString.indexes(of: "AMS ")
let index2 = myHTMLString.indexes(of: "ANT ")
let index3 = myHTMLString.indexes(of: "ART ")
let index4 = myHTMLString.indexes(of: "BIO ")
let index5 = myHTMLString.indexes(of: "BLS ")
let index6 = myHTMLString.indexes(of: "BUS ")
let index7 = myHTMLString.indexes(of: "CHE ")
let index8 = myHTMLString.indexes(of: "CHN ")
let index9 = myHTMLString.indexes(of: "CSI ")
let index10 = myHTMLString.indexes(of: "DAN ")
let index11 = myHTMLString.indexes(of: "ECN ")
let index12 = myHTMLString.indexes(of: "EDU ")
let index13 = myHTMLString.indexes(of: "ELL ")
let index14 = myHTMLString.indexes(of: "ENG ")
let index15 = myHTMLString.indexes(of: "ENV ")
let index16 = myHTMLString.indexes(of: "FRS ")
let index17 = myHTMLString.indexes(of: "GEN ")
let index18 = myHTMLString.indexes(of: "GRS ")
let index19 = myHTMLString.indexes(of: "GRW ")
let index20 = myHTMLString.indexes(of: "HIS ")
let index21 = myHTMLString.indexes(of: "HMN ")
let index22 = myHTMLString.indexes(of: "HPS ")
let index23 = myHTMLString.indexes(of: "ILC ")
let index24 = myHTMLString.indexes(of: "INM ")
let index25 = myHTMLString.indexes(of: "MAT ")
let index26 = myHTMLString.indexes(of: "MUS ")
let index27 = myHTMLString.indexes(of: "PED ")
let index28 = myHTMLString.indexes(of: "PHL ")
let index29 = myHTMLString.indexes(of: "PHY ")
let index30 = myHTMLString.indexes(of: "POL ")
let index31 = myHTMLString.indexes(of: "PSY ")
let index32 = myHTMLString.indexes(of: "SOC ")
let index33 = myHTMLString.indexes(of: "THE ")
let index34 = myHTMLString.indexes(of: "recommended ")

var indexArray = Array<[String.Index]>()

indexArray.append(index1)
//indexArray.append(index2)
//indexArray.append(index3)
//indexArray.append(index4)
//indexArray.append(index5)
//indexArray.append(index6)
//indexArray.append(index7)
//indexArray.append(index8)
//indexArray.append(index9)
//indexArray.append(index10)
//indexArray.append(index11)
//indexArray.append(index12)
//indexArray.append(index13)
//indexArray.append(index14)
//indexArray.append(index15)
//indexArray.append(index16)
//indexArray.append(index17)
//indexArray.append(index18)
//indexArray.append(index19)
//indexArray.append(index20)
//indexArray.append(index21)
//indexArray.append(index22)
//indexArray.append(index23)
//indexArray.append(index24)
//indexArray.append(index25)
//indexArray.append(index26)
//indexArray.append(index27)
//indexArray.append(index28)
//indexArray.append(index29)
//indexArray.append(index30)
//indexArray.append(index31)
//indexArray.append(index32)
//indexArray.append(index33)

private func getClassInfo(atIndex: String.Index, size: Int) -> String {
    var string = String()
    
    for var x in 0...size {
        let charAtIndex = myHTMLString[myHTMLString.index(atIndex, offsetBy: x)]
        if charAtIndex == Character("A") {
            if myHTMLString[myHTMLString.index(atIndex, offsetBy: x-1)] != Character("/") {
                string = string + String(charAtIndex)
            }
        }
        else if charAtIndex != Character("<") && charAtIndex != Character("/") && charAtIndex != Character(">") {
                string = string + String(charAtIndex)
        }
        if string.characters.count == 11 { // add a space here if one doesn't exist
            if myHTMLString[myHTMLString.index(atIndex, offsetBy: x+1)] != Character(" "){
                string = string + " "
            }
        }
        if string.characters.count == 43 { // add a space here if one doesn't exist
            if myHTMLString[myHTMLString.index(atIndex, offsetBy: x+1)] != Character(" "){
                string = string + " "
            }
        }
        if string.characters.count == 2 {
            if string == "  "{ // Get rid of strings that start with spaces
                string = ""
                x = size
            }
            if string == "sp"{ // Get rid of strings that start with sp because there were strings appearing that started with span
                string = ""
                x = size
            }
        }
        if string.characters.count == 5 {  // the string should have the fifth character being a 0,1,2,3,4 if it's a string we desire
            if charAtIndex != Character("0") && charAtIndex != Character("1") && charAtIndex != Character("2") && charAtIndex != Character("3") && charAtIndex != Character("4") {
                string = ""
                x = size
            }
        }
    }
    if string.characters.count > 5 {
        return string
    }
    else{return ""}
}

var splitStringArray = Array<String>()

print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  Schedule  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

for x in 0...indexArray.count-1 {
    if indexArray[x] != [] {
        let currentIndex : [String.Index] = indexArray[x]
        for x in 0...currentIndex.count-1{ //here is where index goes
            let string = getClassInfo(atIndex: currentIndex[x], size: 93)
            if string != "" {
                let index = string.index(string.startIndex, offsetBy: 6)
                let index2 = string.index(string.startIndex, offsetBy: 10)
                if String(describing: index) != " " && String(describing: string.startIndex) != " " && string != "" {splitStringArray.append(string)}
            }
        }
    splitStringArray.append("                                                                                                 ")
    splitStringArray.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    splitStringArray.append("                                                                                                 ")
    }
}

for x in 0...splitStringArray.count-1 {
    print(splitStringArray[x])
}


